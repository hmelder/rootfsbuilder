#!/bin/sh

echo "Hello from post-install.sh"
echo "We are currently in $(pwd)"
echo "Here is a uname -a:"
uname -a